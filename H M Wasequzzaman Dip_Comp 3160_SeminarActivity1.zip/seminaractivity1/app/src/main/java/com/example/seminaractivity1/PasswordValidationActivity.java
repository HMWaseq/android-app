package com.example.seminaractivity1;

import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class PasswordValidationActivity extends AppCompatActivity {

    private EditText etPassword;
    private TextView tvLen, tvLetters, tvUpper, tvDigits, tvSpecial;
    private Button btnValidate;

    private final PasswordValidator validator = new PasswordValidator();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_password_validation);

        etPassword = findViewById(R.id.etPasswordToCheck);
        tvLen = findViewById(R.id.tvRuleLen);
        tvLetters = findViewById(R.id.tvRuleLetters);
        tvUpper = findViewById(R.id.tvRuleUpper);
        tvDigits = findViewById(R.id.tvRuleDigits);
        tvSpecial = findViewById(R.id.tvRuleSpecial);
        btnValidate = findViewById(R.id.btnValidatePassword);

        // initial: all red
        setRuleColors(false, false, false, false, false);

        etPassword.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                PasswordValidator.Result r = validator.check(s.toString());
                setRuleColors(r.lenOK, r.lettersOK, r.upperOK, r.digitsOK, r.specialOK);
            }
            @Override public void afterTextChanged(Editable s) { }
        });

        btnValidate.setOnClickListener(v -> {
            PasswordValidator.Result r = validator.check(etPassword.getText().toString());
            if (r.allOK()) {
                Toast.makeText(this, "Password Validated", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Password not valid yet", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void setRuleColors(boolean len, boolean letters, boolean upper, boolean digits, boolean special) {
        tvLen.setTextColor(len ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
        tvLetters.setTextColor(letters ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
        tvUpper.setTextColor(upper ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
        tvDigits.setTextColor(digits ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
        tvSpecial.setTextColor(special ? Color.parseColor("#2E7D32") : Color.parseColor("#C62828"));
    }
}

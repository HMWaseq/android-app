package com.example.seminaractivity1;

public class PasswordValidator {

    public static class Result {
        public boolean lenOK;
        public boolean lettersOK;
        public boolean upperOK;
        public boolean digitsOK;
        public boolean specialOK;

        public boolean allOK() {
            return lenOK && lettersOK && upperOK && digitsOK && specialOK;
        }
    }

    // Rules:
    // length >= 8
    // letters >= 3
    // uppercase >= 1
    // digits >= 3
    // special >= 1
    public Result check(String pwd) {
        Result r = new Result();
        if (pwd == null) pwd = "";

        int letters = 0, upper = 0, digits = 0, special = 0;

        for (int i = 0; i < pwd.length(); i++) {
            char c = pwd.charAt(i);
            if (Character.isLetter(c)) {
                letters++;
                if (Character.isUpperCase(c)) upper++;
            } else if (Character.isDigit(c)) {
                digits++;
            } else {
                special++;
            }
        }

        r.lenOK = pwd.length() >= 8;
        r.lettersOK = letters >= 3;
        r.upperOK = upper >= 1;
        r.digitsOK = digits >= 3;
        r.specialOK = special >= 1;

        return r;
    }
}

package com.example.seminaractivity1;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * UserStore is a tiny local database for registered users.
 * It saves each user's email, password, and name in SharedPreferences
 * so that LoginActivity can check credentials.
 */
public class UserStore {

    private static final String PREF = "user_store_pref";
    private static final String KEY_USERS = "users_json";

    private static UserStore instance;
    private final SharedPreferences sp;

    /** Singleton accessor */
    public static synchronized UserStore getInstance(Context ctx) {
        if (instance == null) {
            instance = new UserStore(ctx.getApplicationContext());
        }
        return instance;
    }

    /** Private constructor initializes an empty JSON structure if none exists */
    private UserStore(Context appCtx) {
        sp = appCtx.getSharedPreferences(PREF, Context.MODE_PRIVATE);
        if (!sp.contains(KEY_USERS)) {
            try {
                JSONObject root = new JSONObject();
                root.put("users", new JSONObject());
                sp.edit().putString(KEY_USERS, root.toString()).apply();
            } catch (JSONException ignored) { }
        }
    }

    /** Save a new user’s credentials */
    public void registerUser(String email, String password, String name) {
        try {
            JSONObject root = new JSONObject(sp.getString(KEY_USERS, "{}"));
            JSONObject users = root.optJSONObject("users");
            if (users == null) {
                users = new JSONObject();
                root.put("users", users);
            }
            JSONObject obj = new JSONObject();
            obj.put("password", password);
            obj.put("name", name);
            users.put(email, obj);
            sp.edit().putString(KEY_USERS, root.toString()).apply();
        } catch (JSONException ignored) { }
    }

    /** Check if given email/password match a stored user */
    public boolean isValidCredentials(String email, String password) {
        try {
            JSONObject root = new JSONObject(sp.getString(KEY_USERS, "{}"));
            JSONObject users = root.optJSONObject("users");
            if (users == null || !users.has(email)) return false;
            JSONObject obj = users.getJSONObject(email);
            String stored = obj.optString("password", "");
            return stored.equals(password);
        } catch (JSONException e) {
            return false;
        }
    }
}
